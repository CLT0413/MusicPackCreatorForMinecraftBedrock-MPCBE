open("temporary-file/manifest.json","w")
file.write("test")