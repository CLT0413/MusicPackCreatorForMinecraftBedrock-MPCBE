import uuid
import time
import random
import os
import shutil
fom=open("temporary-file/manifest.json","w")
time1=str(time.time()+random.random())
time2=str(time.time()+random.random())
pack_name=input("输入压缩后音乐包名(包括后缀名)")
#pack_music_path=input("输入音乐路径(必须为ogg格式,建议使用工具转换格式,不然可能会有意想不到的bug)")
pack_icon_path=input("输入包封面路径(默认使用 默认文件/pack_icon.png,若无请回车跳过,若有请自行裁剪为256×256的png文件)")
#pack_texts_zhCN=[]
pack_description=input("输入音乐包的描述(若无可直接回车跳过)")
pack_uuid1=str(uuid.uuid3(uuid.NAMESPACE_DNS,time1))
pack_uuid2=str(uuid.uuid3(uuid.NAMESPACE_DNS,time2))
s1='''{\n  "format_version": 1,\n  "header": {\n    "name": "'''+pack_name+'''",\n    "description": "'''+pack_description+'''(Pack By @BlackOrange's MPCBE).",\n    "uuid": "'''+pack_uuid1+'''",\n    "version": [ 1, 0, 0],\n    "min_engine_version": [ 1, 12,  2]\n  },\n  "modules": [\n    {\n      "type": "resources",\n      "uuid": "'''+pack_uuid2+'''",\n      "version": [ 1, 0, 0 ]\n    }\n  ]\n}'''
copyfile()
print("coverage complete")
fom.write(s1)
print("index run end")